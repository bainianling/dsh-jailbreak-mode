/**
 * Jailbreak mode is logged per-agent collaboration state for red-team safety
 * evaluation: while active, the selected strategy's instruction block is
 * appended to the system prompt of every model request, and each claimed user
 * message is wrapped with the strategy's prefix/suffix before it reaches the
 * model. The `/jailbreak` command enters, exits, and switches strategies.
 *
 * The state in force is folded from the session log (`jailbreak/mode`, last
 * one wins), so resume and fork restore it without a live mirror. User
 * selections remain pending until the next accepted in-turn pre-step; the
 * service includes the selected state in the proposed step assembly, then
 * appends `jailbreak/mode` from `agent/pre-step` only when the step is
 * accepted. Same-step request retries reuse their assembly.
 *
 * Agent Note:
 * - .agents/notes/implemented/feature/2026-08-14-jailbreak-mode.md
 *
 * @module @deepseek-ai/dsh-jailbreak-mode
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
export type * from './types.ts';
export type { JailbreakStrategy, TvdHarness, TvdWorkspaceFile } from './strategies.ts';
export { JAILBREAK_STRATEGIES, DEFAULT_JAILBREAK_STRATEGY, strategyById, defaultStrategy } from './strategies.ts';
export { DEFAULT_TVD_SUBDIR, scaffoldTvdWorkspace, renderTvdSystem, workspaceRoot } from './tvd.ts';
export type { TvdTemplateVars } from './tvd.ts';
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /**
         * Whether jailbreak mode is in force from this point on, with the strategy
         * selected for that state: log-only, non-surface, whole-value replace. The
         * last `jailbreak/mode` wins; a log with none folds to inactive through
         * {@link foldJailbreakMode}.
         */
        'jailbreak/mode': {
            active: boolean;
            strategy: string;
        };
    }
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        jailbreakMode: JailbreakModeController;
    }
}
/** The logged state of one session: whole-value fold of `jailbreak/mode`. */
export interface JailbreakState {
    active: boolean;
    strategy: string;
}
/**
 * Deployment-owned jailbreak-mode configuration.
 */
export interface JailbreakModeConfig {
    /**
     * Whether newly created agents start with jailbreak mode active. A preset
     * that exists to evaluate jailbreaks sets this true so every session naming
     * it enters the mode without a `/jailbreak` command; a session's own log
     * still wins (an explicit `/jailbreak off` stays off).
     */
    defaultActive?: boolean;
    /**
     * Strategy id applied to agents that start with jailbreak mode active via
     * {@link defaultActive}. Unknown ids fail loud at plugin load. Defaults to
     * the global default strategy when unset.
     */
    defaultStrategy?: string;
    /**
     * Directory under the session cwd where TVD harnesses are scaffolded. Applies
     * to strategies carrying a `tvd` harness; non-TVD strategies ignore it.
     * Defaults to `tvd`.
     */
    workspaceSubdir?: string;
    /**
     * Classifier model substituted for `{{validatorModel}}` in scaffolded TVD
     * files. Required for a TVD strategy to run its validator; unset or empty
     * degrades that strategy to the prompt-only variant. Defaults to empty.
     */
    validatorModel?: string;
}
/**
 * A validated jailbreak-mode config with deployment defaults applied:
 * `defaultActive` and `workspaceSubdir` are always concrete after resolution.
 */
export interface ResolvedJailbreakModeConfig extends JailbreakModeConfig {
    defaultActive: boolean;
    workspaceSubdir: string;
}
/**
 * Validate deployment-owned jailbreak-mode config. Unknown fields fail at
 * plugin load rather than being ignored.
 *
 * @param config Raw plugin config.
 * @returns A detached validated config with defaults applied.
 */
export declare function resolveConfig(config: JailbreakModeConfig): ResolvedJailbreakModeConfig;
/**
 * Validate a strategy id against the built-in table. Unknown ids fail loud at
 * command time rather than silently degrading to the default.
 *
 * @param strategy The strategy id to validate.
 * @returns The validated strategy id.
 */
export declare function resolveStrategy(strategy: string): string;
/**
 * Whether jailbreak mode is active after the first `end` events. The last
 * `jailbreak/mode` wins; a prefix with none is inactive.
 *
 * @param events The session log or any prefix of it.
 * @param end Fold `events[0, end)`; defaults to the whole log.
 * @returns The folded active flag.
 */
export declare function foldJailbreakActive(events: readonly SessionEvent[], end?: number): boolean;
/**
 * The jailbreak state after the first `end` events. The last `jailbreak/mode`
 * wins; a prefix with none is the default strategy, inactive.
 *
 * @param events The session log or any prefix of it.
 * @param end Fold `events[0, end)`; defaults to the whole log.
 * @returns The folded { active, strategy } state.
 */
export declare function foldJailbreakMode(events: readonly SessionEvent[], end?: number): JailbreakState;
/**
 * `ctx.jailbreakMode`: owns logged jailbreak state, applies and narrates
 * selected state at step start, wraps claimed user messages while active,
 * the `jailbreak:policy` section, and the `/jailbreak` command.
 * UIs observe committed flips through `session/event`; there is no live mirror.
 */
export declare class JailbreakModeController extends Service {
    static inject: string[];
    /** Whether agents created under this composition start active. */
    private readonly defaultActive;
    /** Strategy id applied to agents that start active via `defaultActive`. */
    private readonly defaultStrategy;
    /** Directory under the session cwd where TVD harnesses are scaffolded. */
    private readonly workspaceSubdir;
    /** Template variables substituted into scaffolded TVD files. */
    private readonly tvdVars;
    /** Workspaces already scaffolded per session, so pre-step re-entry does not rewrite them. */
    private readonly scaffolded;
    /**
     * Latest selection per session awaiting the next accepted in-turn pre-step.
     */
    private readonly pendingIntents;
    constructor(ctx: Context, config?: JailbreakModeConfig);
    /**
     * Read the logged jailbreak state and any selection awaiting the next
     * accepted in-turn pre-step.
     *
     * @param agent The agent to read.
     * @returns Current logged state plus a pending selection, when present.
     */
    get(agent: Agent): JailbreakState & {
        pending?: JailbreakState;
    };
    /**
     * Select whether jailbreak mode should be active, optionally switching the
     * strategy in the same flip. Between turns the method appends the change
     * immediately because no in-turn pre-step will run until another prompt
     * starts a turn. The open-turn fold is the idle signal: agent status stays
     * `running` through post-turn checkpointing, when no further in-turn
     * pre-step runs. During an open turn the selection remains pending until the
     * next accepted in-turn pre-step. Repeated selection of the current or
     * already-pending state is a no-op.
     *
     * @param agent The agent to switch.
     * @param active Whether jailbreak mode should be active.
     * @param strategy The strategy id to select (defaults to the current one).
     * @returns what happened: `committed` (logged now), `queued` (awaiting the
     * next accepted in-turn pre-step), `cancelled` (an opposite pending selection
     * was cleared; the logged state already matches), or `noop` (already in that
     * state).
     */
    set(agent: Agent, active: boolean, strategy?: string): 'committed' | 'queued' | 'cancelled' | 'noop';
    /** Apply one pending selection at the next request assembly, narrating a flip. */
    private onBoundary;
    /**
     * Scaffold a TVD strategy's workspace once per session when the `fs` service
     * is composed and the strategy carries a harness. Failures degrade the
     * strategy to the prompt-only variant: the workspace path is still rendered
     * into the system block, but the model must create the files itself.
     *
     * @param agent - the agent whose session owns the workspace.
     * @param strategy - the active strategy; must carry a `tvd` harness.
     * @param signal - forwarded to the fs calls.
     */
    private ensureScaffold;
    /** Build a user-switch notice when the last logged state differs from the target. */
    private narration;
}
export default JailbreakModeController;
//# sourceMappingURL=index.d.ts.map