/**
 * TVD self-loop harness helpers: workspace path derivation, scaffolding, and
 * system-block rendering. A TVD strategy runs the model inside a small coding
 * project: the harness writes Task/Validator/Data skeleton files into the
 * session workspace, the model completes the data so the validator passes, and
 * each failed run returns as a programming error instead of a refusal.
 *
 * The workspace path is derived from the session header's persisted `cwd` plus
 * the strategy id from the logged `jailbreak/mode`, so it is reconstructable
 * from the session log alone (model-visible ⟺ logged). No extra session event
 * is needed.
 *
 * @module @bainianling/dsh-jailbreak-mode/tvd
 */
import type { FileSystem } from '@deepseek-ai/dsh-fs';
import type { JailbreakStrategy, TvdWorkspaceFile } from './strategies.js';
/** Default workspace subdirectory under the session cwd. */
export declare const DEFAULT_TVD_SUBDIR = "tvd";
/** Template variables substituted into scaffolded file content. */
export interface TvdTemplateVars {
    /** Classifier model name substituted for `{{validatorModel}}`. */
    readonly validatorModel: string;
}
/**
 * Derive the TVD workspace root for a session: `<cwd>/<subdir>/<strategyId>`.
 * Pure and deterministic so resume/fork reconstruct it from the log without a
 * live mirror.
 *
 * @param cwd - the session header's persisted working directory.
 * @param subdir - the configured workspace subdirectory (defaults to `tvd`).
 * @param strategyId - the logged strategy id.
 * @returns the absolute workspace root.
 */
export declare function workspaceRoot(cwd: string, subdir: string, strategyId: string): string;
/**
 * Scaffold a TVD strategy's skeleton files into the workspace. Uses the `fs`
 * service so writes honor the backend's atomic-write and containment rules;
 * missing parent directories are created by the backend. Files are overwritten
 * unconditionally so re-activating the same strategy resets the harness.
 *
 * @param fileSystem - the `ctx.fs` service; must be present or the strategy
 *   degrades to the prompt-only variant.
 * @param root - the workspace root to scaffold into.
 * @param files - the skeleton files to write.
 * @param vars - template variables substituted into file content.
 * @param signal - optional abort signal forwarded to the fs calls.
 */
export declare function scaffoldTvdWorkspace(fileSystem: FileSystem, root: string, files: readonly TvdWorkspaceFile[], vars: TvdTemplateVars, signal?: AbortSignal): Promise<void>;
/**
 * Render the system block for a TVD strategy: the base strategy text plus the
 * harness task, the workspace path, and the entrypoint command. The path and
 * command make the harness's location and failure mode explicit so the model
 * runs the validator itself and sees the programming error.
 *
 * @param strategy - the active strategy; must carry a `tvd` harness.
 * @param root - the scaffolded workspace root.
 * @returns the system-block text, or the strategy's plain system when it has no TVD harness.
 */
export declare function renderTvdSystem(strategy: JailbreakStrategy, root: string): string;
//# sourceMappingURL=tvd.d.ts.map