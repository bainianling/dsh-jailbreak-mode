/**
 * The `aimy_skill` tool: explicit access to the bundled toolkit's 102 Attack
 * Skill prompts.
 *
 * Automatic selection (see `./aimy-triggers.js`) covers the common case, but a
 * model that already knows which skill it wants, or wants to browse by
 * category, should not have to guess a file path. This tool is the deterministic
 * counterpart: `list` enumerates the catalog, `search` ranks it against a query
 * using the same triggers as auto-selection, and `load` returns one skill's full
 * body.
 *
 * The tool reads only. It never runs the toolkit's Python and never writes, so
 * mounting it cannot cause a side effect on its own.
 *
 * @module @bainianling/dsh-jailbreak-mode/aimy-tool
 */
import { type AimySkillPaths } from './aimy.js';
/** Name under which the tool registers. */
export declare const AIMY_TOOL_NAME = "aimy_skill";
/**
 * Build the `aimy_skill` tool over a resolved bundle.
 *
 * The index is read lazily on first call and cached inside `aimy-triggers`, so
 * building the tool is free and a bundle with a missing index degrades to an
 * explanatory error rather than a failed mount.
 *
 * @param paths - the resolved bundle location.
 * @returns A registry-ready tool definition.
 */
export declare function defineAimySkillTool(paths: AimySkillPaths): import("@deepseek-ai/dsh-tools").ToolDefinition;
//# sourceMappingURL=aimy-tool.d.ts.map