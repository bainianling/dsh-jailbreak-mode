/**
 * Automatic skill selection for the bundled aimy-skill toolkit.
 *
 * The `aimy-skill` strategy ships 102 Attack Skill prompts. Telling the model
 * where they live is not the same as getting the relevant one in front of it:
 * a model that has to decide to go read a directory frequently does not, and
 * the decision is invisible. This module makes the selection deterministic.
 *
 * The chain is:
 *
 * 1. {@link loadAimyTriggerIndex} reads `assets/aimy-skill-triggers.json`, which
 *    `scripts/generate-aimy-triggers.mjs` derives from the vendored tree — the
 *    skills, their categories, their companion documents and their trigger
 *    words all come from disk, so a re-vendor cannot leave this stale.
 * 2. {@link matchAimySkills} scores the step's own user text against those
 *    triggers. A `strong` hit (the skill's full name, or a curated alias such
 *    as `sqli` / `sql注入`) weighs enough to route on its own; `weak` hits are
 *    the individual words of a directory name and must accumulate.
 * 3. {@link renderAimySkillInjection} wraps the winning `SKILL.md` for
 *    injection as instructions context.
 *
 * Everything here is pure or read-only: no network, no writes, no execution of
 * the toolkit's Python. Failures return `undefined` so a caller degrades to the
 * prompt-only strategy rather than failing a step.
 *
 * @module @bainianling/dsh-jailbreak-mode/aimy-triggers
 */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { AimySkillPaths } from './aimy.js';
/** Most skills one step may auto-load, regardless of how many match. */
export declare const AIMY_INJECTION_MAX_SKILLS = 2;
/**
 * Ceiling on the total injected characters per step. The largest single
 * `SKILL.md` is ~31 KB; the cap keeps a verbose match from crowding out the
 * user's own request. An over-budget skill is truncated with a pointer to its
 * absolute path rather than dropped.
 */
export declare const AIMY_INJECTION_CHAR_BUDGET = 48000;
/** One skill's routing record, as generated from the vendored tree. */
export interface AimyTriggerEntry {
    /** Directory name under `skills/`, and the skill's identity. */
    readonly name: string;
    /** Upstream category id from `categories.yaml`. */
    readonly category: string;
    /** The `description` field of the skill's frontmatter. */
    readonly description: string;
    /** `SKILL.md` location, relative to the bundle root. */
    readonly path: string;
    /** Companion documents in the same directory, when any. */
    readonly companions?: readonly string[];
    /** Decisive triggers: the full name plus curated aliases. */
    readonly strong: readonly string[];
    /** Supporting triggers: single name words, decisive only in combination. */
    readonly weak?: readonly string[];
}
/** The whole generated index. Weighting travels with the data, not in code. */
export interface AimyTriggerIndex {
    /** Upstream toolkit version the index was generated from. */
    readonly version: string;
    /** Upstream commit the vendored tree was taken from. */
    readonly commit: string;
    /** Number of skills, matching the vendored tree. */
    readonly skillCount: number;
    /** Score contributed by one `strong` hit. */
    readonly strongWeight: number;
    /** Score contributed by one `weak` hit. */
    readonly weakWeight: number;
    /** Minimum score for a skill to be selected. */
    readonly threshold: number;
    /** Every skill, sorted by name. */
    readonly skills: readonly AimyTriggerEntry[];
}
/** One selected skill and the evidence that selected it. */
export interface AimySkillMatch {
    /** The matched routing record. */
    readonly entry: AimyTriggerEntry;
    /** Accumulated trigger weight. */
    readonly score: number;
    /** The triggers that fired, strongest first. */
    readonly hits: readonly string[];
}
/**
 * Durable record of one automatic skill selection. The names ride the source so
 * a later step can see what has already been put in front of the model without
 * re-reading the injected prose.
 */
export interface AimySkillInjectionSource {
    readonly kind: 'aimy-skill';
    readonly form: 'instructions';
    /** Exactly the skills this message injected, in injection order. */
    readonly names: readonly string[];
}
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        'aimy-skill': AimySkillInjectionSource;
    }
}
/**
 * Absolute path of the generated trigger index for a resolved bundle.
 *
 * Both generated indexes sit beside the bundle rather than inside it, so the
 * vendored tree stays byte-identical to upstream. {@link AimySkillPaths} already
 * carries the location, so this is a field read — the constant exists only to
 * keep that layout in one place.
 *
 * @param paths - the resolved bundle location.
 * @returns Absolute path of the trigger index JSON.
 */
export declare function aimyTriggersPath(paths: AimySkillPaths): string;
/**
 * Read and validate the generated trigger index.
 *
 * A missing or malformed index is not an error: the caller keeps the
 * prompt-only behavior. The verdict is cached per path, including the failure,
 * so a broken install does not re-read on every step.
 *
 * @param paths - the resolved bundle location.
 * @returns The parsed index, or `undefined` when it is absent or unusable.
 */
export declare function loadAimyTriggerIndex(paths: AimySkillPaths): AimyTriggerIndex | undefined;
/**
 * Validate an untrusted parsed value into an {@link AimyTriggerIndex}.
 *
 * The shape is checked field by field because the index is generated data:
 * a schema drift should disable auto-selection, not crash a step.
 *
 * @param raw - the parsed JSON value.
 * @returns The validated index, or `undefined` when the shape does not hold.
 */
export declare function parseAimyTriggerIndex(raw: unknown): AimyTriggerIndex | undefined;
/**
 * Score one step's text against the index and return the skills worth loading.
 *
 * Selection is deliberately conservative: a skill needs {@link
 * AimyTriggerIndex.threshold} points, which one `strong` hit satisfies alone but
 * a lone `weak` word never does. Ties break toward the more specific match — the
 * longer matched trigger wins — and then by name, so the result is stable.
 *
 * @param index - the generated trigger index.
 * @param text - the step's own user text (never injected content).
 * @param limit - maximum matches to return.
 * @param exclude - skill names already injected in this session.
 * @returns Matches, best first; empty when nothing clears the threshold.
 */
export declare function matchAimySkills(index: AimyTriggerIndex, text: string, limit?: number, exclude?: ReadonlySet<string>): AimySkillMatch[];
/**
 * Triggers that cannot route alone, however many skills claim them.
 *
 * Two sources, deliberately combined: the count catches words shared across the
 * table (`api`, `auth`, `injection`), and {@link CLASS_NOUN_TRIGGERS} catches
 * bare class nouns that only one or two skills list yet still appear in
 * ordinary prose. Counting alone would miss the second kind; a curated list
 * alone would rot when the bundle is re-vendored, so the count carries the load
 * and the list covers the residue.
 *
 * @param index - the generated trigger index.
 * @returns The set of non-decisive triggers, computed once per index.
 */
export declare function genericTriggers(index: AimyTriggerIndex): ReadonlySet<string>;
/**
 * Read one skill's `SKILL.md` from the bundle.
 *
 * @param paths - the resolved bundle location.
 * @param entry - the skill to read; `path` is relative to the bundle root.
 * @returns The file body, or `undefined` when it cannot be read.
 */
export declare function readAimySkill(paths: AimySkillPaths, entry: AimyTriggerEntry): string | undefined;
/**
 * Render one skill for injection as instructions context.
 *
 * The body is the upstream `SKILL.md` verbatim — the same text `tool-skill`
 * would inject for a `/<name>` gesture — framed by where it came from, where
 * the full file lives, and which companion documents exist. The frame is what
 * lets the model trust the injection and read further on its own.
 *
 * @param paths - the resolved bundle location.
 * @param entry - the skill being injected.
 * @param content - that skill's `SKILL.md` body.
 * @param reason - the triggers that selected it, rendered for the model.
 * @returns The injection text.
 */
export declare function renderAimySkillInjection(paths: AimySkillPaths, entry: AimyTriggerEntry, content: string, reason: string): string;
/** One rendered injection: the message text plus the names it put in context. */
export interface AimyInjection {
    readonly text: string;
    readonly names: string[];
}
/**
 * Render the step's matched skills into one injectable block, honouring both
 * budgets.
 *
 * @param paths - the resolved bundle location.
 * @param matches - the selected skills, best first.
 * @param budget - maximum total characters to emit; defaults to {@link AIMY_INJECTION_CHAR_BUDGET}.
 * @returns The block and its names, or `undefined` when nothing could be read.
 */
export declare function renderAimyInjections(paths: AimySkillPaths, matches: readonly AimySkillMatch[], budget?: number): AimyInjection | undefined;
/**
 * Skill names already injected into this session, from its own durable log.
 *
 * This is what stops a skill from being re-injected on every step of a long
 * conversation: the injection is a logged `user/message` carrying its names.
 *
 * @param events - the session log.
 * @returns Every auto-loaded skill name, in first-seen order.
 */
export declare function injectedAimySkills(events: readonly SessionEvent[]): Set<string>;
/**
 * Render the whole index as a plain catalog, for the `aimy_skill` tool's `list`
 * action.
 *
 * @param index - the generated trigger index.
 * @param category - optional category filter.
 * @returns One line per skill: name, category, description.
 */
export declare function renderAimySkillCatalog(index: AimyTriggerIndex, category?: string): string;
/**
 * Render one skill for the `aimy_skill` tool's `load` action: the full body plus
 * its absolute location.
 *
 * @param paths - the resolved bundle location.
 * @param entry - the skill to render.
 * @returns The rendered skill, or `undefined` when its file cannot be read.
 */
export declare function renderAimySkillLoad(paths: AimySkillPaths, entry: AimyTriggerEntry): string | undefined;
/** Look one skill up by exact name. */
export declare function aimySkillByName(index: AimyTriggerIndex, name: string): AimyTriggerEntry | undefined;
//# sourceMappingURL=aimy-triggers.d.ts.map