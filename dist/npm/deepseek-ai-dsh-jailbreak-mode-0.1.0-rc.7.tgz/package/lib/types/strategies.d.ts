/**
 * Built-in jailbreak strategies for red-team safety evaluation.
 *
 * A strategy describes how the harness rewrites model input while jailbreak
 * mode is active: an optional `system` block appended to the system prompt
 * (the whole-mode injection that reaches every model), and an optional
 * `prefix`/`suffix` pair wrapped around each claimed user message (the
 * per-message injection that mirrors classic prefix-injection attacks).
 *
 * The templates below are public, widely documented jailbreak techniques
 * (DAN, Developer Mode, STAN, prefix injection, persona switching, authorized
 * CTF framing) plus one TVD self-loop harness, collected from open red-teaming
 * literature and competitions such as the DEF CON AI Village GRT contest.
 * They ship only so deployments can run reproducible safety evaluations;
 * disabling the plugin removes them entirely.
 *
 * @module @deepseek-ai/dsh-jailbreak-mode/strategies
 */
/** One workspace file scaffolded for a TVD strategy. Path is relative to the workspace root. */
export interface TvdWorkspaceFile {
    /** Workspace-relative file path; parent directories are created on write. */
    readonly path: string;
    /** File content; `{{validatorModel}}` is substituted at scaffold time. */
    readonly content: string;
}
/**
 * A TVD self-loop harness: a small coding project whose validator really runs.
 * The agent must fill a data file's empty slots so the validator passes; each
 * failure comes back as a programming error, so the agent keeps fixing the
 * task instead of refusing. This is the environment-channel variant of a
 * jailbreak strategy (the prompt-injection variants use system/prefix/suffix).
 */
export interface TvdHarness {
    /** Skeleton files written into the session workspace at activation. */
    readonly files: readonly TvdWorkspaceFile[];
    /** Command the agent must run (and see fail) inside the workspace, e.g. `python guard.py`. */
    readonly entrypoint: string;
    /** Task text appended to the system block: what the harness does and what the agent must complete. */
    readonly task: string;
}
/** One jailbreak strategy: how model input is rewritten while active. */
export interface JailbreakStrategy {
    /** Stable id used by `/jailbreak <id>` and the projection. */
    readonly id: string;
    /** Short display name (localized by the UI; keys are stable English). */
    readonly name: string;
    /** One-line purpose shown in strategy pickers. */
    readonly description: string;
    /**
     * Instruction block appended to the system prompt while this strategy is
     * active. Empty string contributes nothing.
     */
    readonly system: string;
    /** Per-message prefix injected before each claimed user message. */
    readonly prefix: string;
    /** Per-message suffix injected after each claimed user message. */
    readonly suffix: string;
    /**
     * Optional TVD self-loop harness. When present, the harness is scaffolded
     * into the session workspace and the system block renders the task plus the
     * workspace path instead of relying on prompt injection alone.
     */
    readonly tvd?: TvdHarness;
}
/**
 * The default strategy id applied by a bare `/jailbreak` (and by the UI chip
 * when no strategy has been chosen yet).
 */
export declare const DEFAULT_JAILBREAK_STRATEGY = "dan";
/** Built-in strategy table, in picker order. */
export declare const JAILBREAK_STRATEGIES: readonly JailbreakStrategy[];
/**
 * Look up a strategy by its stable id.
 *
 * @param id The strategy id to look up.
 * @returns The strategy with `id`, or `undefined` when unknown.
 */
export declare function strategyById(id: string): JailbreakStrategy | undefined;
/**
 * The default strategy for bare `/jailbreak` entry and empty-log folds.
 *
 * @returns The default strategy (falls back to the first table entry).
 */
export declare function defaultStrategy(): JailbreakStrategy;
//# sourceMappingURL=strategies.d.ts.map